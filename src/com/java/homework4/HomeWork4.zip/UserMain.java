package com.java.homework4;

public class UserMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		UserManager user = new UserManager();
		user.addMemberUser();
		user.displayAllUser();

	}
}
